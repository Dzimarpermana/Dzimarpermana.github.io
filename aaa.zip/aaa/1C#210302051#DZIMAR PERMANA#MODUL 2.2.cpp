 #include <iostream>
#include <conio.h>
using namespace std;
struct {
int NIM;
char Nama[30];
char kelas[2];
}Mhs;
main()
{
cout<<"masukan NIM : ";cin>>Mhs.NIM;
fflush(stdin);
cout<<"masukan nama: ";cin>>Mhs.Nama;fflush(stdin);
cout<<"masukan kelas : ";cin>>Mhs.kelas;
cout<<"Mahasiswa dengan Nim "<<Mhs.NIM<<" bernama "<<Mhs.Nama<<" kelas "<<Mhs.kelas;
getche();
}
