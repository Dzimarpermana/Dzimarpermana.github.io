#include <iostream>
#include <conio.h>
using namespace std;

typedef int angka;
typedef float desimal;
typedef char huruf;
typedef char String[100];
main()
{
 angka umur;
 desimal nilai;
 huruf kelas;
 String nama;
 cout<<"nama anda : ";
 cin.get(nama, 100); fflush(stdin);
 cout<<"umur anda : ";
 cin>>umur;
 cout<<"kelas anda: ";
 cin>>kelas;
 cout<<"IP anda : ";
 cin>>nilai;
 cout<<"\n\n"<<nama<<" dari kelas "<<kelas<<" berumur "<<umur<<" dengan ip "<<nilai;
 getche();
}
